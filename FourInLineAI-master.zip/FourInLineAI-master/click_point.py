import cv2
import numpy as np

mtx = np.array([[793.6108905, 0., 201.56630283],
                [0., 811.4936059, 228.46068121],
                [0., 0., 1.]])

dist = np.array([[-0.76366812, -0.9773434, 0.01325336, 0.10824405, 1.83247511]])


def mouse_drawing(event, x, y, flags, params):
    if event == cv2.EVENT_LBUTTONDOWN:
        print(x, y)
        circles.append((x, y))


cap = cv2.VideoCapture(3, cv2.CAP_DSHOW)
cv2.namedWindow("Frame")
cv2.setMouseCallback("Frame", mouse_drawing)
circles = []

if __name__ == "__main__":
    while True:
        ret, img = cap.read()
        img = cv2.undistort(img, mtx, dist, None, mtx)
        img = img[30:410, 40:600]
        print(img.shape)

        for center_position in circles:
            cv2.circle(img, center_position, 5, (0, 0, 255), -1)
        print(circles)

        cv2.imshow("Frame", img)

        key = cv2.waitKey(1)
        if key & 0xFF == ord('q'):
            for i in range(0, 42, 7):
                print(circles[i:i+7])
            break
        elif key == ord("d"):
            circles = []

    cap.release()
    cv2.destroyAllWindows()
