def go_to_position(pos):
    print("Go to position: ", pos)
    print("I am on position: ", pos)


def drop_dics():
    inp = input("Press anything when you drop dics")
    print("I droped dics")


def open_grasper():
    print("I opened grasper")


def close_grasper():
    print("I closed grasper")


def push_disc():
    print("I pushed dics")


def go_home():
    print("I went home")


def open_trapdoor():
    print("I opened sink")


def close_trapdoor():
    print("I closed trapdoor")


