import pickle
import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg# Read in the saved objpoints and imgpoints
mtx = np.array([[793.6108905,    0.,         201.56630283],
              [  0. ,        811.4936059,  228.46068121],
              [  0.,           0.,           1.        ]])

dist = np.array([[-0.76366812, -0.9773434,   0.01325336,  0.10824405,  1.83247511]])


img = cv2.imread('dis.jpg')
undist = cv2.undistort(img, mtx, dist, None, mtx)

cv2.imshow("ok", img)
cv2.imshow("dist", undist)
if cv2.waitKey(0) & 0xFF == ord('q'):
       exit(0)

# ax1.set_title('Original Image', fontsize=50)
# ax2.imshow(undist)
# ax2.set_title('Undistorted Image', fontsize=50)
# plt.subplots_adjust(left=0., right=1, top=0.9, bottom=0.)